package code;
public class MainBD {

	public static void main(String[] args)
	{
		FinestraQuery x = new FinestraQuery();
		Interface i=new Interface();
		
		// TODO Auto-generated method stub

	}

}
 