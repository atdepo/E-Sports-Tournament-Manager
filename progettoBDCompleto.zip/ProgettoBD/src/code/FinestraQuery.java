package code;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;

public class FinestraQuery extends JFrame {

	private JPanel contentPane;

 

	/**
	 * Create the frame.
	 */
	public FinestraQuery() {
		super("Gestione Tornei");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1400,900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JTextArea Results = new JTextArea();
		JScrollPane scrollV = new JScrollPane(Results);
		scrollV.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollV, BorderLayout.CENTER);
		
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(9,2));
		contentPane.add(panel, BorderLayout.WEST);
		
		JButton btnNewButton = new JButton("Query1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 250);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(5,1));
				panel1.add(new JLabel("Nome Torneo"));
				panel1.add(new JLabel("Inserire data aaaa-mm-gg"));
				panel1.add(new JLabel("Nome Gioco"));
				panel1.add(new JLabel("Indirizzo Struttura"));
				panel1.add(new JLabel("CAP"));
				tmp.add(panel1);
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				JTextField t5= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(5,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				panel.add(t5);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Interface.query1(t1.getText(),t2.getText(),t3.getText(),t4.getText(),t5.getText());
						Results.setText("Torneo Aggiunto!!");
						tmp.dispose();
					}
				});
				tmp.add(btn);
				
				}
		});
		
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Query2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 300);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(7,1));
				panel1.add(new JLabel("Codice Fiscale"));
				panel1.add(new JLabel("Recapito"));
				panel1.add(new JLabel("Indirizzo"));
				panel1.add(new JLabel("Nome"));
				panel1.add(new JLabel("Cognome"));
				panel1.add(new JLabel("Data Nascita aaaa-mm-gg"));
				panel1.add(new JLabel("Codice Torneo"));
				tmp.add(panel1);
				
				JTextField t1 = new JTextField();
				JTextField t2 = new JTextField();
				JTextField t3 = new JTextField();
				JTextField t4 = new JTextField();
				JTextField t5 = new JTextField();
				JTextField t6 = new JTextField();
				JTextField t7 = new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(7,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				panel.add(t5);
				panel.add(t6);
				panel.add(t7);
				tmp.add(panel);
				
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try {
						Interface.query2(t1.getText(),t2.getText(),t3.getText(),t4.getText(),t5.getText(),t6.getText(),Integer.parseInt(t7.getText()));
						Results.setText("Organizzatore aggiunto");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				 
				tmp.add(btn);
				
			}
		});
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Query3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 200);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(4,1));
				panel1.add(new JLabel("Nome Struttura"));
				panel1.add(new JLabel("Indirizzo Struttura"));
				panel1.add(new JLabel("CAP"));
				panel1.add(new JLabel("Capienza struttura"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(4,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						
						try{
							Interface.query3(t1.getText(),t2.getText(),t3.getText(),Integer.parseInt(t4.getText()));
						Results.setText("Struttura aggiunta!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
				
				}
		});
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Query4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(400, 100);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(2,1));
				panel1.add(new JLabel("Nome Sponsor"));
				panel1.add(new JLabel("Codice Torneo"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(2,1));
				panel.add(t1);
				panel.add(t2);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try {
						Interface.query4(t1.getText(),Integer.parseInt(t2.getText()));
						Results.setText("Sponsor aggiunto!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
				
			}
		});
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Query5");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 150);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(3,1));
				panel1.add(new JLabel("Nome Squadra"));
				panel1.add(new JLabel("Nazionalit� squadra"));
				panel1.add(new JLabel("Codice torneo"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Interface.query5(t1.getText(),t2.getText(),Integer.parseInt(t3.getText()));
						Results.setText("Squadra aggiunta!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
				
			}
		});
		panel.add(btnNewButton_4);
		
		
		JButton btn4a= new JButton("Query6");
		btn4a.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 150);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(1,1));
				panel1.add(new JLabel("Nome Gioco"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(1,1));
				panel.add(t1);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Interface.query15(t1.getText());
						Results.setText("Gioco aggiunto!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
			}
		});
		
		panel.add(btn4a);
		
		JButton btn4b= new JButton("Query7");
		btn4b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 150);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(3,1));
				panel1.add(new JLabel("Tipo"));
				panel1.add(new JLabel("Numero Giocatori"));
				panel1.add(new JLabel("Nome Gioco"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Interface.query16(t1.getText(),Integer.parseInt(t2.getText()),t3.getText());
						Results.setText("Modalit� aggiunta!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
			}
		});
		
		panel.add(btn4b);
		
		JButton btn4c= new JButton("Query8");
		btn4c.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 300);
				tmp.setLayout(new GridLayout(1,7));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(7,1));
				panel1.add(new JLabel("Codice Fiscale"));
				panel1.add(new JLabel("Specializzazione"));
				panel1.add(new JLabel("Recapito"));
				panel1.add(new JLabel("Indirizzo"));
				panel1.add(new JLabel("Nome"));
				panel1.add(new JLabel("Cognome"));
				panel1.add(new JLabel("Data Nascita aaaa-mm-gg"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				JTextField t5= new JTextField();
				JTextField t6= new JTextField();
				JTextField t7= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(7,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				panel.add(t5);
				panel.add(t6);
				panel.add(t7);
				
				
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Interface.query17(t1.getText(),t2.getText(),t3.getText(),t4.getText(),t5.getText(),t6.getText(),t7.getText());
						Results.setText("Tecnico aggiunto!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
			}
		});
		
		panel.add(btn4c);
		
		JButton btn4d= new JButton("Query9");
		btn4d.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 300);
				tmp.setLayout(new GridLayout(1,7));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(7,1));
				panel1.add(new JLabel("Nickname"));
				panel1.add(new JLabel("Nome"));
				panel1.add(new JLabel("Cognome"));
				panel1.add(new JLabel("Ruolo"));
				panel1.add(new JLabel("Data Nascita"));
				panel1.add(new JLabel("Squadra"));
				panel1.add(new JLabel("Cod Tecnico"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				JTextField t5= new JTextField();
				JTextField t6= new JTextField();
				JTextField t7= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(7,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				panel.add(t5);
				panel.add(t6);
				panel.add(t7);
				
				
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Interface.query18(t1.getText(),t2.getText(),t3.getText(),t4.getText(),t5.getText(),t6.getText(),t7.getText());
						Results.setText("Giocatore aggiunto!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
			}
		});
		
		panel.add(btn4d);
		
		
		
		JButton btnNewButton_5 = new JButton("Query10");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Results.setText("Selezionare tutte le squadre che hanno partecipato ad almeno due tornei"
						+ " la cui modalit� presenta almeno 4 giocatori\n\n"+Interface.query6());
			
			}
		});
		panel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Query11");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText("Selezionare i tecnici che assistono pi� di un giocatore\n\n"+Interface.query7());
			}
		});
		panel.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Query12");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 100);
				tmp.setLayout(new GridLayout(1, 3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new BorderLayout());
				panel1.add(new JLabel("Anno"));
				tmp.add(panel1,BorderLayout.WEST);
				
				JTextField t1= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(new JPanel());
				panel.add(t1,BorderLayout.CENTER);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Results.setText("Selezionare i giocatori nati dopo un certo anno\n\n"+Interface.query8(t1.getText()));
						
						tmp.dispose();
					}
				});
				tmp.add(btn);
			}
		});
		panel.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Query13");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 100);
				tmp.setLayout(new GridLayout(1, 3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new BorderLayout());
				panel1.add(new JLabel("Numero tornei"));
				tmp.add(panel1,BorderLayout.WEST);
				
				JTextField t1= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(new JPanel());
				panel.add(t1,BorderLayout.CENTER);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try {
						Results.setText("Selezionare gli organizzatori che hanno organizzato un certo numero di tornei\n\n"
								+Interface.query9(Integer.parseInt(t1.getText())));
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);	
						}
					}
				});
				tmp.add(btn);
			}
		});
		panel.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Query14");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Results.setText("Selezionare tutte le squadre che hanno partecipato ad almeno un torneo"
						+ " il cui gioco presenta pi� di una modalit�\n\n"+Interface.query10());
				
			}
		});
		panel.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("Query15");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText("Selezionare i giocatori il cui NickName inizia per �K�\n\n"+Interface.query11());
				
				
			}
		});
		panel.add(btnNewButton_10);
		
		
		JButton btnNewButton_11 = new JButton("Query16");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 100);
				tmp.setLayout(new GridLayout(1, 3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new BorderLayout());
				panel1.add(new JLabel("Ruolo"));
				tmp.add(panel1,BorderLayout.WEST);
				
				JTextField t1= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(new JPanel());
				panel.add(t1,BorderLayout.CENTER);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Results.setText("Selezionare nome e cognome dei giocatori che "
								+ "giocano in un certo ruolo assistiti da un tecnico che assiste pi� un giocatore\n\n"+Interface.query12(t1.getText()));
						tmp.dispose();
					}
				});
				tmp.add(btn);
			}
		});
		panel.add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("Query17");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 150);
				tmp.setLayout(new GridLayout(1, 3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(3,1));
				panel1.add(new JLabel("Ruolo Giocatore"));
				panel1.add(new JLabel("Nome Torneo"));
				panel1.add(new JLabel("Nome Gioco"));
				tmp.add(panel1,BorderLayout.WEST);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Results.setText("Selezionare tutti i giocatori che giocano in un certo ruolo "
								+ "in un dato torneo di uno specifico gioco\n\n"+Interface.query13(t1.getText(),t2.getText(),t3.getText()));
						tmp.dispose();
					}
				});
				tmp.add(btn);
			}
		});
		panel.add(btnNewButton_12);
		
		
		JButton btnNewButton_13 = new JButton("Query18");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 100);
				tmp.setLayout(new GridLayout(1, 3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new BorderLayout());
				panel1.add(new JLabel("Nome Torneo"));
				tmp.add(panel1,BorderLayout.WEST);
				
				JTextField t1= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(new JPanel());
				panel.add(t1,BorderLayout.CENTER);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
					
						Results.setText("Stampare il numero dei partecipanti ad un torneo\n\n"+Interface.query14(t1.getText()));
						tmp.dispose();
					}
				});
				tmp.add(btn);
			}
		});
		panel.add(btnNewButton_13);
		
		
		
		
		JButton btnNewButton_14 = new JButton("CONNESSIONE");
		btnNewButton_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText(Interface.connessione());
			}
		});
		
		JButton btnNewButton_15 = new JButton("ESCI");
		btnNewButton_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText(Interface.uscita());
				
			}
		});
		JPanel bt= new JPanel();
		bt.setVisible(true);
		bt.setLayout(new GridLayout(1,4));
		
		bt.add(new JPanel());
		bt.add(btnNewButton_14);
		bt.add(btnNewButton_15);
	
		bt.add(new JPanel());
		
		contentPane.add(bt, BorderLayout.NORTH);
		setVisible(true);
	}

}
