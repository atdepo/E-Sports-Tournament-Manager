package code;

import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Interface {
	 
	private static Connection con = null ;
	public static String connessione () {

	  try {
			  //caricamento e registrazione driver
		  	   String s=" ";
			   Class.forName("com.mysql.cj.jdbc.Driver"); //Carica il Driver
			   String url ="jdbc:mysql://localhost:3306/gestionetornei?useSSL=false&serverTimezone=UTC";
		       String username = "root";
			   String pwd = "pippo";  
			   con = DriverManager.getConnection(url,username,pwd);
			   s="Connessione riuscita!!";
			   return s;
	  }
	  catch(Exception e)
	  {
		  return "Connessione fallita";  
	  }
	}
	
	public static String uscita() {
		
		try {
			con.close();
			return "Connessione chiusa correttamente\n";
		} catch (SQLException e) {
			return "Chiusura connessione fallita\n";
		}
	}
	
	public static void query1(String nome,String data,String nomeGioco,String indirizzo,String CAP)  {
   	
    try {
   			String sql="INSERT INTO torneo(nome,datatorneo,codgioco,indirizzostruttura,capstruttura) VALUES(?,?,?,?,?)";
	        PreparedStatement query = con.prepareStatement(sql);
	        query.setString(1, nome);
	        query.setString(2, data);
	        query.setString(3, nomeGioco);
	        query.setString(4,indirizzo);
	        query.setString(5, CAP);
	        query.executeUpdate();
            query.close();
            
         }
    catch (SQLException e)
    {
       System.out.println(e);
       JPanel pane= new JPanel();
       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }
}
	
	public static void query2(String CF,String recapito,String indirizzo,String nome,String cognome,String nascita,int cod) {

		    try {
		   			String sql =  "INSERT INTO staff VALUES(?,?,?,?,?,?);";
		   			String sql2= "INSERT INTO organizzatore values(?);"; 
		   			String sql3= "INSERT INTO organizza VALUES(?,?);\r\n";
			        PreparedStatement query = con.prepareStatement(sql);
			        PreparedStatement query2 = con.prepareStatement(sql2);
			        PreparedStatement query3 = con.prepareStatement(sql3);
			        query.setString(1, CF);
			        query.setString(2, recapito);
			        query.setString(3, indirizzo);
			        query.setString(4, nome);
			        query.setString(5, cognome);
			        query.setString(6, nascita);
			        query2.setString(1, CF);
			        query3.setInt(1, cod);
			        query3.setString(2, CF);
			        query.executeUpdate();
			        query2.executeUpdate();
			        query3.executeUpdate();
			        query.close();
			        query2.close();
			        query3.close();
		         }
		    catch (NumberFormatException |SQLException e )
		    {
		       System.out.println(e);
		       JPanel pane= new JPanel();
		       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
		    
		    }
		
	}
	
	public static void query3(String nome,String indirizzo,String CAP,int capienza) {

		 try {
	   			String p="Aggiungere un nuovo torneo ";
	   			// ESECUZIONE INTERROGAZIONE
	   			String sql="INSERT INTO struttura VALUES(?,?,?,?);";
		        PreparedStatement query = con.prepareStatement(sql);
		        query.setString(1, nome);
		        query.setString(2, indirizzo);
		        query.setString(3, CAP);
		        query.setInt(4,capienza);
		        query.executeUpdate();
	            query.close();
	         }
	    catch (SQLException e)
	    {
	       System.out.println(e);
	       JPanel pane= new JPanel();
	       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
	    }	
	}
	
	public static void query4(String nome,int codTorneo) {

		try {
   			String p="Aggiungere un nuovo torneo ";
   			// ESECUZIONE INTERROGAZIONE
   			String sql="INSERT INTO sponsor VALUES(?,?)";
	        PreparedStatement query = con.prepareStatement(sql);
	        query.setString(1, nome);
	        query.setInt(2,codTorneo);
	        query.executeUpdate();
            query.close();
         }
    catch (SQLException e)
    {
       System.out.println(e);
       JPanel pane= new JPanel();
       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }	
		
	}
	
	public static void query5(String nome,String nazionalit�,int cod) {

		try {
   			
   			
   			String sql="INSERT INTO squadra VALUES (?,?);";
	        String sql2="INSERT INTO composto VALUES(?,?);";
   			PreparedStatement query = con.prepareStatement(sql);
   			PreparedStatement query2 = con.prepareStatement(sql2);
	        query.setString(1, nome);
	        query.setString(2, nazionalit�);
	        query2.setString(1, nome);
	        query2.setInt(2,cod);
	        
	        query.executeUpdate();
	        query2.executeUpdate();
	        query2.close();
            query.close();
         }
    catch (SQLException e)
    {
       System.out.println(e);
       JPanel pane= new JPanel();
       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }	
		
	}
	
	public static String query6() {

		String r="";
		try {
	        
	        Statement query = con.createStatement();
	        ResultSet result = query.executeQuery("SELECT s.nome\r\n" + 
	        		"FROM Squadra as s, Composto as c, Torneo as t,gioco as g, modalita as m\r\n" + 
	        		"WHERE s.nome=c.CodSquadra AND c.CodTorneo=t.Codice AND t.CodGioco=g.nome AND\r\n"+
	        		" m.nomegioco=g.nome AND m.NumeroGiocatori>4 AND s.nome IN \r\n"+
	        		"(SELECT s.nome \r\n" + 
	        		" FROM 	squadra as s, composto as c\r\n" + 
	        		" WHERE s.nome=c.CodSquadra\r\n" + 
	        		" GROUP BY (s.nome)\r\n" + 
	        		" HAVING count(*)>=2)\r\n" + 
	        		"GROUP BY s.nome\r\n" + 
	        		"");
	    
            while (result.next())
            {
               String nome = result.getString("nome");
               r+=nome+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
	}
	
	public static String query7() {
		String r="";
		try {
	        
	        Statement query = con.createStatement();
	        ResultSet result = query.executeQuery("SELECT t.codStaff,s.nome,s.cognome\r\n" + 
	        		"FROM tecnico as t,giocatore as g,staff as s\r\n" + 
	        		"where t.codStaff=g.codTecnico AND s.CF=t.codStaff\r\n" + 
	        		"GROUP BY t.codStaff\r\n" + 
	        		"HAVING count(*)>1;");
	    
            while (result.next())
            {
               String nome = result.getString("nome");
               String cognome= result.getString("cognome");
               r+=nome+" | "+cognome+" |"+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
	}
	
	public static String query8(String anno) {

		
		String r="";
		try {
	        
	        String sql = "SELECT g.Nickname\r\n" + 
	        			 "from giocatore as g\r\n" + 
	        			 "where YEAR(dataN)>?;";
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1, anno);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            String nick= result.getString("nickname");
               r+=nick+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
		
	}
	
	public static String query9(int organizzati) {

		String r="";
		try {
	        
	        String sql = "SELECT o.CodStaff\r\n" + 
	        		"from organizzatore as o, torneo as t,organizza as org\r\n" + 
	        		"where o.CodStaff=org.codOrganizzatore AND t.Codice=org.codTorneo\r\n" + 
	        		"group by o.CodStaff\r\n" + 
	        		"Having count(*)=?";
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setInt(1, organizzati);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            String codice= result.getString("codStaff");
               r+=codice+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
		
	}
	
	public static String query10() {

		String r="";
	
		try {
	        
	        Statement query = con.createStatement();
	        ResultSet result = query.executeQuery("SELECT s.nome\r\n" + 
	        		"			FROM squadra as s, composto as c, torneo as t\r\n" + 
	        		"			where s.nome=c.CodSquadra AND c.CodTorneo=t.Codice AND (SELECT count(*)\r\n" + 
	        		"			FROM modalita as m,gioco as g\r\n" + 
	        		"			WHERE m.nomegioco=g.nome AND t.codGioco=g.nome)>1");
	    
            while (result.next())
            {
               String nome = result.getString("nome");
               r+=nome+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
	}
	
	public static String query11() {

		String r="";
	
		try {
	        
	        Statement query = con.createStatement();
	        ResultSet result = query.executeQuery("SELECT g.nickname\r\n" + 
	        		"FROM giocatore as g\r\n" + 
	        		"WHERE g.Nickname LIKE \"K%\";");
	    
            while (result.next())
            {
               String nick = result.getString("Nickname");
               r+=nick+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }

	}
	
	public static String query12(String ruolo) {

		String r="";
		try {
	        
	        String sql = "SELECT g.nome,g.cognome\r\n" + 
	        		"FROM giocatore as g\r\n" + 
	        		"WHERE g.ruolo=? AND g.codtecnico IN (SELECT t.codStaff\r\n" + 
	        		"										FROM tecnico as t,giocatore as g\r\n" + 
	        		"										WHERE t.codstaff=g.codtecnico\r\n" + 
	        		"										GROUP BY t.codstaff\r\n" + 
	        		"										HAVING count(*)>1);";
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1,ruolo);
	       ResultSet result= query.executeQuery();
	     
            while (result.next())
            {  
            String nome= result.getString("nome");
            String cognome= result.getString("cognome");
               r+=nome+" | "+ cognome + " | "+"\n\n";
    
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
	}
	
	public static String query13(String ruolo,String nomeTorneo,String nomeGiocatore) {
		
		String r="";
		try {
	        
	        String sql = "SELECT g.nickname\r\n" + 
	        		"FROM giocatore as g, squadra as s, composto as c, torneo as t, gioco as gi  \r\n" + 
	        		"WHERE g.nomesquadra=s.nome AND c.codsquadra=s.nome AND c.codtorneo=t.codice \r\n"
	        		+"AND t.codgioco=gi.nome AND g.ruolo=? AND t.nome=? AND gi.nome=? ;\r\n";
	        
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1, ruolo);
	       query.setString(2, nomeTorneo);
	       query.setString(3, nomeGiocatore);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            String nick= result.getString("nickname");
               r+=nick+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
	}
	
	public static String query14(String nome) {

		String r="";
		try {
	        
	        String sql = "SELECT Count(*) as NumPartecipanti\r\n" + 
	        		"FROM torneo as t, composto as c\r\n" + 
	        		"WHERE t.nome=? AND t.codice=c.codtorneo;";
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1,nome);
	       ResultSet result= query.executeQuery();
	       
	       result.next();
            int o=result.getInt("numPartecipanti");
            result.close();
            query.close();
            return String.valueOf(o);
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
		
		
	}
	
	public static void query15(String nome) {
		try {
			
			String sql="INSERT INTO gioco VALUES (?);";
			PreparedStatement query= con.prepareStatement(sql);
			query.setString(1, nome);
			query.executeUpdate();
			
		}
		catch(SQLException e) {
			System.out.println(e);
	        JPanel pane= new JPanel();
	        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static void query16(String tipo,int numero,String gioco) {
		try {
			
			String sql="INSERT INTO modalita VALUES (?,?,?);";
			PreparedStatement query= con.prepareStatement(sql);
			query.setString(1, tipo);
			query.setInt(2, numero);
			query.setString(3, gioco);
			query.executeUpdate();
			
		}
		catch(SQLException e) {
			System.out.println(e);
	        JPanel pane= new JPanel();
	        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static void query17(String CF,String spec,String recapito,String indirizzo,String nome,String cognome,String nascita) {
		try {
			String sql ="INSERT INTO staff VALUES(?,?,?,?,?,?);";
			String sql2="INSERT INTO tecnico VALUES (?,?);";
			PreparedStatement query= con.prepareStatement(sql);
			PreparedStatement query1= con.prepareStatement(sql2);
			query.setString(1, CF);
	        query.setString(2, recapito);
	        query.setString(3, indirizzo);
	        query.setString(4, nome);
	        query.setString(5, cognome);
	        query.setString(6, nascita);
			query1.setString(1, CF);
			query1.setString(2, spec);
			query.executeUpdate();
			query1.executeUpdate();
			
		}
		catch(SQLException e) {
			System.out.println(e);
	        JPanel pane= new JPanel();
	        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static void query18(String nick,String nome,String cognome,String ruolo,String datan,String squadra,String codTecnico) {
		try {
			String sql="INSERT INTO giocatore VALUES (?,?,?,?,?,?,?);";
			PreparedStatement query= con.prepareStatement(sql);
			query.setString(1, nick);
			query.setString(2, nome);
			query.setString(3, cognome);
			query.setString(4, ruolo);
			query.setString(5, datan);
			query.setString(6, squadra);
			query.setString(7, codTecnico);
			query.executeUpdate();
			
		}
		catch(SQLException e) {
			System.out.println(e);
	        JPanel pane= new JPanel();
	        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
		}
	}
}
	